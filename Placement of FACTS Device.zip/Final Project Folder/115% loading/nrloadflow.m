% global filename
VA=busVoltageAngle_GIPFC*180/pi;
VM=busVoltage_GIPFC.*cos(busVoltageAngle_GIPFC)+1j*busVoltage_GIPFC.*sin(busVoltageAngle_GIPFC);
Iij = zeros(nbus,nbus);
Sij = zeros(nbus,nbus);
Si = zeros(nbus,1);
I = Y_matrix*VM;
Im = abs(I);
Ia = angle(I);
BMva = 100;
for m = 1:nline
    p = frombus(m); q = tobus(m);
    Iij(p,q) = (VM(p)-VM(q))*yline(m) + blinecharge(m)/linetap(m)^2*VM(p);
    Iij(q,p) = (VM(q)-VM(p))*yline(m) + blinecharge(m)*VM(q);
end
for m = 1:nbus
    for n = 1:nbus
        if m ~= n
            Sij(m,n) = VM(m)*conj(Iij(m,n))*BMva;
        end
    end
end
Lij = zeros(nline,1);
for m = 1:nline
    p = frombus(m); q = tobus(m);
    Smva(m)=abs(Sij(p,q));
    PIJ(m) = real(Sij(p,q));
    QIJ(m) = imag(Sij(p,q));
    PJI(m) = real(Sij(q,p));
    QJI(m) = imag(Sij(q,p)); 
    Lij(m) = Sij(p,q) + Sij(q,p);
end
Lpij = real(Lij);
Lqij = imag(Lij);
for i = 1:nbus
    for k = 1:nbus
        Si(i) = Si(i) + conj(VM(i))* VM(k)*Y_matrix(i,k)*BMva;
    end
end
Pi = real(Si);
Qi = -imag(Si);
Pg = Pi+(Pload*BMva);
Qg = Qi+(Qload*BMva)-(Qsh*BMva);
% LOAD FLOW ANALYSIS
xlswrite("pflow.xlsx",{'B.NO','VOLTAGE','THETA','PINJ','QINJ','PGEN','QGEN'...
    'PLOAD','QLOAD','QSH','FROMBUS','TOBUS','PFLOW','QFLOW','SFLOW'...
    ,'FROMBUS','TOBUS','PFLOW','QFLOW','SFLOW','PLOSS','QLOSS','MVAlimit'},'Sheet1','A2')
data1=[bus busVoltage VA Pi Qi Pg Qg (Pload*BMva) (Qload*BMva) (Qsh*BMva)];
xlswrite("pflow.xlsx",data1,'Sheet1','A3');
data2=[sum(Pg) sum(Qg) sum(Pload*BMva) sum(Qload*BMva) sum(Qsh*BMva)];
xlswrite("pflow.xlsx",data2,'Sheet1',strcat('F',num2str(nbus+3)));
data3=[frombus tobus PIJ' QIJ' (sqrt(PIJ.^2+QIJ.^2))' tobus frombus PJI' QJI' (sqrt(PJI.^2+QJI.^2))' ...
       Lpij Lqij lineMVAlimit];
xlswrite("pflow.xlsx",data3,'Sheet1','K3');
data4=[sum(PIJ) sum(QIJ) 0 0 0 sum(PJI) sum(QJI) 0 sum(Lpij) sum(Lqij)];
xlswrite("pflow.xlsx",data4,'Sheet1',strcat('M',num2str(nline+3)));