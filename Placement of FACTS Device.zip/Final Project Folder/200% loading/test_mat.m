clc; clear; close all;

busdata = xlsread("busdata.xlsx");

busdata = busdata(1:30, :);    %30 bus system, not 32 bus. 

Base_MVA = 100;

nbus = length(busdata(:,1));
busType = busdata(:, 2);
busVoltage = busdata(:, 3);
busVoltageAngle = busdata(:, 4) * pi/180;
Pgen = busdata(:, 5) /Base_MVA ;
Qgen = busdata(:, 6) /Base_MVA ;
Pload = busdata(:, 7) /Base_MVA ;
Qload = busdata(:, 8) /Base_MVA ;
Qmin = busdata(:, 9) /Base_MVA ;
Qmax = busdata(:, 10) /Base_MVA ;
Qsh = busdata(:, 11) /Base_MVA ;

%% line data
linedata = xlsread("linedata.xlsx");

linedata = linedata(1:40,:);

nline = length(linedata(:,1));
frombus = linedata(:, 2);
tobus = linedata(:, 3);
rline = linedata(:, 4);
xline = linedata(:, 5);
linecharging = linedata(:, 6);
linetap = linedata(:, 7);
lineMVAlimit = linedata(:, 8);

%% Y bus
zline = rline + 1i*xline;
yline = 1./zline;
blinecharge = 1i*linecharging;

%% GIPFC data
gipfcdata = xlsread("gipfcdata.xlsx");
gipfc_no = gipfcdata(:, 1);
gipfc_send = gipfcdata(:, 2);
gipfc_rec1 = gipfcdata(:, 3);
gipfc_rec2 = gipfcdata(:, 4);
gipfc_rec3 = gipfcdata(:, 5);
gipfc_vse1 = gipfcdata(:, 6);
gipfc_vse2 = gipfcdata(:, 7);
gipfc_thse1 = gipfcdata(:, 8) * pi/180;    %radians
gipfc_thse2 = gipfcdata(:, 9) * pi/180;
gipfc_xse1 = gipfcdata(:, 10);
gipfc_xse2 = gipfcdata(:, 11);   %already given in pu
gipfc_qsh = gipfcdata(:, 12) ;   %maybe already given in pu, will not be divided by base MVA
gipfc_xsh = gipfcdata(:, 13);
gipfc_vsh = gipfcdata(:, 14);
gipfc_thsh = gipfcdata(:, 15) * pi/180;

%% Locations
busLines = [frombus tobus];

slack_bus_ind = find(busType == 1);  %eliminating slack bus rows and cols
PV_bus_ind = find(busType == 2)


busLines(slack_bus_ind,:) = [];  %elimination of slack bus connected line

size_busLines = size(busLines);
                                    %eliminating PV bus connected lines

k = 0;

for i = 1:size_busLines(1)
    for j = 1:2    % size_busLines(2)
        for l = 1:length(PV_bus_ind)

            if ( busLines(i,j) == PV_bus_ind(l) || busLines(i,j) == slack_bus_ind )
                k = k+1;
                ind(k) = i; 
            end 

        end
    end
end

busLines(ind,:) = [];

size_busLines = size(busLines);
% comb_mat = []; 
count = 0;
for i = 1:(size_busLines(1))

    a = busLines(i,1); b = busLines(i,2);
    for k = 1 : (size_busLines(1))
        if k~=i
            if ( busLines(k,1) ~= a & busLines(k,2) ~= a & busLines(k,1) ~= b & busLines(k,2) ~= b)
                count = count+1;
                comb_mat(count,:) = [a b busLines(k,1) busLines(k,2)];
            else
                continue
            end

        end
    end

end

comb_mat_col1 = comb_mat(:,1); comb_mat_col2 = comb_mat(:,2);
comb_mat_col3 = comb_mat(:,3); comb_mat_col4 = comb_mat(:,4);
% comb_mat2 = [comb_mat_col2 comb_mat_col3 comb_mat_col4 comb_mat_col1];
% comb_mat3 = [comb_mat_col3 comb_mat_col4 comb_mat_col1 comb_mat_col2];
% comb_mat4 = [comb_mat_col4 comb_mat_col1 comb_mat_col2 comb_mat_col3];

comb_mat2 = [comb_mat_col2 comb_mat_col1 comb_mat_col3 comb_mat_col4];

combination_matrix = [comb_mat; comb_mat2];
