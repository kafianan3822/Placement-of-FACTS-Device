

busdata = xlsread("busdata.xlsx");

busdata = busdata(1:30, :);    %30 bus system, not 32 bus. 

Base_MVA = 100;
bus = busdata(:, 1);
nbus = length(busdata(:,1));
busType = busdata(:, 2);
busVoltage_GIPFC = busdata(:, 3);
busVoltageAngle_GIPFC = busdata(:, 4) * pi/180;
Pgen = busdata(:, 5) /Base_MVA ;
Qgen = busdata(:, 6) /Base_MVA ;
Pload = busdata(:, 12) /Base_MVA ;
Qload = busdata(:, 13) /Base_MVA ;
Qmin = busdata(:, 9) /Base_MVA ;
Qmax = busdata(:, 10) /Base_MVA ;
Qsh = busdata(:, 11) /Base_MVA ;

%% line data
linedata = xlsread("linedata.xlsx");

linedata = linedata(1:40,:);

nline = length(linedata(:,1));
frombus = linedata(:, 2);
tobus = linedata(:, 3);
rline = linedata(:, 4);
xline = linedata(:, 5);
linecharging = linedata(:, 6);
linetap = linedata(:, 7);
lineMVAlimit = linedata(:, 8);

%% Y bus
zline = rline + 1i*xline;
yline = 1./zline;
blinecharge = 1i*linecharging;

%% GIPFC data
gipfcdata = xlsread("gipfcdata.xlsx");
% gipfcloc = xlsread("gipfc_locations.xlsx");
gipfc_no = gipfcdata(:, 1);
gipfc_send = gipfcdata(:, 2);
gipfc_rec1 = gipfcdata(:, 3);
gipfc_rec2 = gipfcdata(:, 4);
gipfc_rec3 = gipfcdata(:, 5);
gipfc_vse1 = gipfcdata(:, 6);
gipfc_vse2 = gipfcdata(:, 7);
gipfc_thse1 = gipfcdata(:, 8) * pi/180;    %radians
gipfc_thse2 = gipfcdata(:, 9) * pi/180;
gipfc_xse1 = gipfcdata(:, 10);
gipfc_xse2 = gipfcdata(:, 11);   %already given in pu
gipfc_qsh = gipfcdata(:, 12) ;   %maybe already given in pu, will not be divided by base MVA
gipfc_xsh = gipfcdata(:, 13);
gipfc_vsh = gipfcdata(:, 14);
gipfc_thsh = gipfcdata(:, 15) * pi/180;

gipfc_length = length(gipfc_no); 
gipfc_bse1 = 1 / gipfc_xse1 ;
gipfc_bse2 = 1 / gipfc_xse2 ;
gipfc_bsh = 1 / gipfc_xsh ;


%end of gipfc data

%% Y-Bus Matrix 

Y_matrix = zeros(nbus,nbus);
for k = 1:nline
    Y_matrix(frombus(k) , tobus(k)) = Y_matrix(frombus(k), tobus(k)) - yline(k)/linetap(k);
    Y_matrix(tobus(k) , frombus(k)) = Y_matrix(frombus(k), tobus(k));
end

for i_bus = 1:nbus
    for i_line = 1:nline
        if frombus(i_line) == i_bus 
            Y_matrix(i_bus,i_bus) = Y_matrix(i_bus,i_bus) + yline(i_line)/(linetap(i_line)^2) + blinecharge(i_line);
        elseif tobus(i_line) == i_bus
            Y_matrix(i_bus,i_bus) = Y_matrix(i_bus,i_bus) + yline(i_line) + blinecharge(i_line);
        end
    end
end

G = real(Y_matrix);
B = imag(Y_matrix);

Ymag = abs(Y_matrix);
Yphase = angle(Y_matrix);

%% P and Q calculations

Pinj = Pgen - Pload;
Qinj = Qgen - Qload + Qsh ;

tolerance = 1;
iteration = 1;


while(tolerance > 0.0001 && iteration<=20)
    P_GIPFC = zeros(nbus,1);
    Q_GIPFC = zeros(nbus,1);

    for i= 1:nbus
        for k = 1:nbus
            P_GIPFC(i) = P_GIPFC(i) + busVoltage_GIPFC(i)*busVoltage_GIPFC(k)*Ymag(i,k) ...
                * cos(busVoltageAngle_GIPFC(k)-busVoltageAngle_GIPFC(i)+Yphase(i,k));
            Q_GIPFC(i) = Q_GIPFC(i) - busVoltage_GIPFC(i)*busVoltage_GIPFC(k)*Ymag(i,k) ...
                * sin(busVoltageAngle_GIPFC(k)-busVoltageAngle_GIPFC(i)+Yphase(i,k));
        end
    end

    for i = 1:nbus
        if(busType(i) == 2 && iteration>2)   %why >2?
            if ( (Q_GIPFC(i) + Qload(i)) < Qmin(i) )
                Qinj(i) = Qmin(i) - Qload(i);
                busType(i) = 3;
            elseif ( (Q_GIPFC(i) + Qload(i)) > Qmax(i) )
                Qinj(i) = Qmax(i) - Qload(i);
                busType(i) = 3;
            end
        end
    end

    %% Mismatches

    delP = Pinj - P_GIPFC;
    delQ = Qinj - Q_GIPFC;

    %Updated mismatches due to extra Power injected by GIPFC
    if gipfc_send ~= 0   %checking if GIPFC is incorporated or not
        a = gipfc_send; b = gipfc_rec1; c = gipfc_rec2; d = gipfc_rec3;

        %P
        Pinj_gipfc_send = busVoltage_GIPFC(a) * busVoltage_GIPFC(b) * gipfc_bse1 * sin(busVoltageAngle_GIPFC(a)-busVoltageAngle_GIPFC(b))...
            - busVoltage_GIPFC(a)*gipfc_vse1*gipfc_bse1*sin(busVoltageAngle_GIPFC(a)-gipfc_thse1)...
            - busVoltage_GIPFC(a)*gipfc_vsh*gipfc_bsh*sin(busVoltageAngle_GIPFC(a)-gipfc_thsh);
        delP(a) = delP(a) + Pinj_gipfc_send;

        Pinj_gipfc_rec1 = -busVoltage_GIPFC(a)*busVoltage_GIPFC(b)*gipfc_bse1*sin(busVoltageAngle_GIPFC(a)-busVoltageAngle_GIPFC(b))...
            + busVoltage_GIPFC(b)*gipfc_vse1*gipfc_bse1*sin(busVoltageAngle_GIPFC(b)-gipfc_thse1);
        delP(b) = delP(b) + Pinj_gipfc_rec1;

        Pinj_gipfc_rec2 = busVoltage_GIPFC(c)*busVoltage_GIPFC(d)*gipfc_bse2*sin(busVoltageAngle_GIPFC(c)-busVoltageAngle_GIPFC(d))...
            - busVoltage_GIPFC(c)*gipfc_vse2*gipfc_bse2*sin(busVoltageAngle_GIPFC(c)-gipfc_thse2);
        delP(c) = delP(c) + Pinj_gipfc_rec2;

        Pinj_gipfc_rec3 = -busVoltage_GIPFC(c)*busVoltage_GIPFC(d)*gipfc_bse2*sin(busVoltageAngle_GIPFC(c)-busVoltageAngle_GIPFC(d))...
            + busVoltage_GIPFC(d)*gipfc_vse2*gipfc_bse2*sin(busVoltageAngle_GIPFC(d)-gipfc_thse2);
        delP(d) = delP(d) + Pinj_gipfc_rec3;


        %Q
        Qinj_gipfc_send = busVoltage_GIPFC(a)*busVoltage_GIPFC(b)*gipfc_bse1*cos(busVoltageAngle_GIPFC(a)-busVoltageAngle_GIPFC(b))...
            - busVoltage_GIPFC(a)*gipfc_vse1*gipfc_bse1*cos(busVoltageAngle_GIPFC(a)-gipfc_thse1)...
            - busVoltage_GIPFC(a)*gipfc_vsh*gipfc_bsh*cos(busVoltageAngle_GIPFC(a)-gipfc_thsh)...
            - busVoltage_GIPFC(a)^2 * gipfc_bse1;
        delQ(a) = delQ(a) + Qinj_gipfc_send;

        Qinj_gipfc_rec1 = busVoltage_GIPFC(a)*busVoltage_GIPFC(b)*gipfc_bse1*cos(busVoltageAngle_GIPFC(a)-busVoltageAngle_GIPFC(b))...
            + busVoltage_GIPFC(b)*gipfc_vse1*gipfc_bse1*cos(busVoltageAngle_GIPFC(b)-gipfc_thse1)...
            - busVoltage_GIPFC(b)^2 * gipfc_bse1;
        delQ(b) = delQ(b) + Qinj_gipfc_rec1;

        Qinj_gipfc_rec2 = busVoltage_GIPFC(c)*busVoltage_GIPFC(d)*gipfc_bse2*cos(busVoltageAngle_GIPFC(c)-busVoltageAngle_GIPFC(d))...
            - busVoltage_GIPFC(c)*gipfc_vse2*gipfc_bse2*cos(busVoltageAngle_GIPFC(c)-gipfc_thse2)...
            - busVoltage_GIPFC(c)^2 * gipfc_bse2;
        delQ(c) = delQ(c) + Qinj_gipfc_rec2;

        Qinj_gipfc_rec3 = busVoltage_GIPFC(c)*busVoltage_GIPFC(d)*gipfc_bse2*cos(busVoltageAngle_GIPFC(c)-busVoltageAngle_GIPFC(d))...
            + busVoltage_GIPFC(d)*gipfc_vse2*gipfc_bse2*cos(busVoltageAngle_GIPFC(d)-gipfc_thse2)...
            - busVoltage_GIPFC(d)^2 * gipfc_bse2;
        delQ(d) = delQ(d) + Qinj_gipfc_rec3;


    end


    Mismatch = [delP; delQ];

    %% SubJacobians

    J1 = zeros(nbus, nbus);
    for i = 1:nbus
        for j = 1:nbus

             if (i == j)
                for k = 1:nbus
                    J1(i,j) = J1(i,j) - busVoltage_GIPFC(k)*busVoltage_GIPFC(i) *Ymag(i,k) ...
                        *sin(busVoltageAngle_GIPFC(k)-busVoltageAngle_GIPFC(i)+Yphase(i,k));
                end
                J1(i,j) = - busVoltage_GIPFC(i)^2 * B(i,j) - J1(i,j);
%                  J1(i,j) = - busVoltage(i)^2 * B(i,j) - Q(i);
             else
                 J1(i,j) = - Ymag(i,j)*busVoltage_GIPFC(i)*busVoltage_GIPFC(j)* ...
                     sin(busVoltageAngle_GIPFC(j)-busVoltageAngle_GIPFC(i)+Yphase(i,j));
             end
        end
    end


    J2 = zeros(nbus, nbus);
    for i = 1:nbus
        for j = 1:nbus
            
             if i == j 
                for k = 1:nbus
                    J2(i,j) = J2(i,j) + busVoltage_GIPFC(i)*busVoltage_GIPFC(k)*Ymag(i,k) ...
                        *cos(busVoltageAngle_GIPFC(k)-busVoltageAngle_GIPFC(i)+Yphase(i,k));
                end
                J2(i,j) = J2(i,j) + busVoltage_GIPFC(i)^2 * G(i,j);
%                  J2(i,j) = P(i) + busVoltage(i)^2 * G(i,j); 
             else
                 J2(i,j) = busVoltage_GIPFC(i)*busVoltage_GIPFC(j)*Ymag(i,j) ...
                         *cos(busVoltageAngle_GIPFC(j)-busVoltageAngle_GIPFC(i)+Yphase(i,j));
             end

        end 
    end


  J3 = zeros(nbus, nbus);
    for i = 1:nbus
        for j = 1:nbus
            
             if i == j 
                for k = 1:nbus
                    J3(i,j) = J3(i,j) + busVoltage_GIPFC(i)*busVoltage_GIPFC(k)*Ymag(i,k) ...
                        *cos(busVoltageAngle_GIPFC(k)-busVoltageAngle_GIPFC(i)+Yphase(i,k));
                end
                J3(i,j) = J3(i,j) - busVoltage_GIPFC(i)^2 * G(i,j);
%                  J3(i,j) = P(i) - busVoltage(i)^2 * G(i,j); 
             else
                 J3(i,j) = - busVoltage_GIPFC(i)*busVoltage_GIPFC(j)*Ymag(i,j) ...
                         *cos(busVoltageAngle_GIPFC(j)-busVoltageAngle_GIPFC(i)+Yphase(i,j));
             end

        end 
    end



    J4 = zeros(nbus, nbus);
    for i = 1:nbus
        for j = 1:nbus
            
             if i == j 
                for k = 1:nbus
                    J4(i,j) = J4(i,j) - busVoltage_GIPFC(i)*busVoltage_GIPFC(k)*Ymag(i,k) ...
                        *sin(busVoltageAngle_GIPFC(k)-busVoltageAngle_GIPFC(i)+Yphase(i,k));
                end
                J4(i,j) = J4(i,j) - busVoltage_GIPFC(i)^2 * B(i,j);
%                  J4(i,j) = Q(i) - busVoltage(i)^2 * B(i,j); 
             else
                 J4(i,j) = - busVoltage_GIPFC(i)*busVoltage_GIPFC(j)*Ymag(i,j) ...
                         *sin(busVoltageAngle_GIPFC(j)-busVoltageAngle_GIPFC(i)+Yphase(i,j));
             end

        end 
    end


    Jacobian_NR = [J1 J2; J3 J4];


%% GIPFC jacobians  ----------------------------------
    J_gipfc_1 = zeros(nbus);
    for i = 1:nbus
        for j = 1:nbus
            if ( i == gipfc_send ) && ( j == gipfc_rec1)
                J_gipfc_1(i, i) = busVoltage_GIPFC(i)*busVoltage_GIPFC(j)*gipfc_bse1 ...
                    * cos(busVoltageAngle_GIPFC(i)-busVoltageAngle_GIPFC(j)) ...
                    - busVoltage_GIPFC(i) * gipfc_vse1 * gipfc_bse1 * ...
                    cos(busVoltageAngle_GIPFC(i) - gipfc_thse1) ...
                    - busVoltage_GIPFC(i) * gipfc_vsh * gipfc_bsh * ...
                    cos(busVoltageAngle_GIPFC(i) - gipfc_thsh)  ;
                
                J_gipfc_1(i, j) = -busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse1 ...
                    * cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j)) ;

%                 J_gipfc_1(j, i) = -busVoltage(i) * busVoltage(j) * gipfc_bse1 ...
%                     * cos(busVoltageAngle(i) - busVoltageAngle(j)) ;
                
                J_gipfc_1(j, i) = J_gipfc_1(i, j);

                J_gipfc_1(j, j) = busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse1 ...
                    * cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j) ) + ...
                    busVoltage_GIPFC(j) * gipfc_vse1 * gipfc_bse1 * ...
                    cos(busVoltageAngle_GIPFC(j) - gipfc_thse1) ;

            elseif ( j == gipfc_send ) && ( i == gipfc_rec1)     %maybe redundant 
                    
                J_gipfc_1(i, i) = busVoltage_GIPFC(i)*busVoltage_GIPFC(j)*gipfc_bse1 ...
                    * cos(busVoltageAngle_GIPFC(i)-busVoltageAngle_GIPFC(j)) ...
                    - busVoltage_GIPFC(i) * gipfc_vse1 * gipfc_bse1 * ...
                    cos(busVoltageAngle_GIPFC(i) - gipfc_thse1) ...
                    - busVoltage_GIPFC(i) * gipfc_vsh * gipfc_bsh * ...
                    cos(busVoltageAngle_GIPFC(i) - gipfc_thsh)  ;
                
                J_gipfc_1(i, j) = -busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse1 ...
                    * cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j)) ;

%                 J_gipfc_1(j, i) = -busVoltage(i) * busVoltage(j) * gipfc_bse1 ...
%                     * cos(busVoltageAngle(i) - busVoltageAngle(j)) ;
                
                J_gipfc_1(j, i) = J_gipfc_1(i, j);

                J_gipfc_1(j, j) = busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse1 ...
                    * cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j) ) + ...
                    busVoltage_GIPFC(j) * gipfc_vse1 * gipfc_bse1 * ...
                    cos(busVoltageAngle_GIPFC(j) - gipfc_thse1) ;
            end
        end

        for k = 1:nbus

            if ( i == gipfc_send ) && ( k == gipfc_rec2 )
                J_gipfc_1(i , k) = 0;
            elseif ( k == gipfc_send ) && ( i == gipfc_rec2 )
                J_gipfc_1(i , k) = 0;        % WARNING: index interchanged
                                        % to make symmetric component 0
            end
        end

        for l = 1:nbus

            if ( i == gipfc_send ) && ( l == gipfc_rec3 )
                J_gipfc_1(i , l) = 0;
            elseif ( l == gipfc_send ) && ( i == gipfc_rec3 )
                J_gipfc_1(i , l) = 0;          
            end
        end
    end


    for i = 1 : nbus
        for j = 1 : nbus

            if ( i == gipfc_rec2 ) && ( j == gipfc_rec3 ) 
                J_gipfc_1(i , i) = busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse2 * ...
                    cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j)) - ...
                    busVoltage_GIPFC(i) * gipfc_vse2 * gipfc_bse2 * ...
                    cos(busVoltageAngle_GIPFC(i) - gipfc_thse2);

                J_gipfc_1(i , j) = -busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse2 * ...
                    cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j)) ;

                J_gipfc_1(j , i) = J_gipfc_1(i , j);

                J_gipfc_1(j, j) = busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse2 * ...
                    cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j)) + ...
                    busVoltage_GIPFC(j) * gipfc_vse2 * gipfc_bse2 * ...
                    cos(busVoltageAngle_GIPFC(j) - gipfc_thse2 ) ;

            elseif ( j == gipfc_rec2 ) && ( i == gipfc_rec3 )
                J_gipfc_1(i , i) = busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse2 * ...
                    cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j)) - ...
                    busVoltage_GIPFC(i) * gipfc_vse2 * gipfc_bse2 * ...
                    cos(busVoltageAngle_GIPFC(i) - gipfc_thse2);

                J_gipfc_1(i , j) = -busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse2 * ...
                    cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j)) ;

                J_gipfc_1(j , i) = J_gipfc_1(i , j);

                J_gipfc_1(j, j) = busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse2 * ...
                    cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j)) + ...
                    busVoltage_GIPFC(j) * gipfc_vse2 * gipfc_bse2 * ...
                    cos(busVoltageAngle_GIPFC(j) - gipfc_thse2 ) ;

            end
        end
    end


    J_gipfc_2 = zeros(nbus);
    for i = 1:nbus
        for j = 1:nbus
            if ( i == gipfc_send ) && ( j == gipfc_rec1)
                J_gipfc_2(i,i) = busVoltage_GIPFC(j)*gipfc_bse1*...
                    sin(busVoltageAngle_GIPFC(i)-busVoltageAngle_GIPFC(j)) - gipfc_vse1*gipfc_bse1*...
                    sin(busVoltageAngle_GIPFC(i)-gipfc_thse1) - ...
                    gipfc_vsh*gipfc_bsh*sin(busVoltageAngle_GIPFC(i)-gipfc_thsh);

                J_gipfc_2(i,j) = busVoltage_GIPFC(i)*gipfc_bse1*sin(busVoltageAngle_GIPFC(i)-busVoltageAngle_GIPFC(j));

                J_gipfc_2(j,i) = -busVoltage_GIPFC(j)*gipfc_bse1*sin(busVoltageAngle_GIPFC(i)-busVoltageAngle_GIPFC(j));

                J_gipfc_2(j,j) = -busVoltage_GIPFC(i)*gipfc_bse1*sin(busVoltageAngle_GIPFC(i)-busVoltageAngle_GIPFC(j)) + ...
                    gipfc_vse1*gipfc_bse1*sin(busVoltageAngle_GIPFC(j)-gipfc_thse1);

            elseif ( j == gipfc_send ) && ( i == gipfc_rec1)
                J_gipfc_2(i,i) = busVoltage_GIPFC(j)*gipfc_bse1*...
                    sin(busVoltageAngle_GIPFC(i)-busVoltageAngle_GIPFC(j)) - gipfc_vse1*gipfc_bse1*...
                    sin(busVoltageAngle_GIPFC(i)-gipfc_thse1) - ...
                    gipfc_vsh*gipfc_bsh*sin(busVoltageAngle_GIPFC(i)-gipfc_thsh);

                J_gipfc_2(i,j) = busVoltage_GIPFC(i)*gipfc_bse1*sin(busVoltageAngle_GIPFC(i)-busVoltageAngle_GIPFC(j));

                J_gipfc_2(j,i) = -busVoltage_GIPFC(j)*gipfc_bse1*sin(busVoltageAngle_GIPFC(i)-busVoltageAngle_GIPFC(j));

                J_gipfc_2(j,j) = -busVoltage_GIPFC(i)*gipfc_bse1*sin(busVoltageAngle_GIPFC(i)-busVoltageAngle_GIPFC(j)) + ...
                    gipfc_vse1*gipfc_bse1*sin(busVoltageAngle_GIPFC(j)-gipfc_thse1);
            end
        end

        for k = 1:nbus
            if ( i == gipfc_send ) && ( k == gipfc_rec2)
                J_gipfc_2(i,k) = 0;
            elseif ( k == gipfc_send ) && ( i == gipfc_rec2)
                J_gipfc_2(i,k) = 0;
            end
        end

        for l = 1:nbus
            if ( i == gipfc_send ) && ( l == gipfc_rec3)
                J_gipfc_2(i,l) = 0;
            elseif ( l == gipfc_send ) && ( i == gipfc_rec3)
                J_gipfc_2(i,l) = 0;
            end
        end
    end

 for k = 1:nbus
        for l = 1:nbus
            if ( k == gipfc_rec2 ) && ( l == gipfc_rec3)
                J_gipfc_2(k,k) = busVoltage_GIPFC(l)*gipfc_bse2*sin(busVoltageAngle_GIPFC(k)-busVoltageAngle_GIPFC(l)) - ...
                    gipfc_vse2*gipfc_bse2*sin(busVoltageAngle_GIPFC(k)-gipfc_thse2);
                J_gipfc_2(k,l) = busVoltage_GIPFC(k)*gipfc_bse2*sin(busVoltageAngle_GIPFC(k)-busVoltageAngle_GIPFC(l));
                J_gipfc_2(l,k) = -busVoltage_GIPFC(l)*gipfc_bse2*sin(busVoltageAngle_GIPFC(k)-busVoltageAngle_GIPFC(l));
                J_gipfc_2(l,l) = -busVoltage_GIPFC(k)*gipfc_bse2*sin(busVoltageAngle_GIPFC(k)-busVoltageAngle_GIPFC(l)) + ...
                    gipfc_vse2*gipfc_bse2*sin(busVoltageAngle_GIPFC(l)-gipfc_thse2);
            elseif ( l == gipfc_rec2 ) && ( k == gipfc_rec3)
                J_gipfc_2(k,k) = busVoltage_GIPFC(l)*gipfc_bse2*sin(busVoltageAngle_GIPFC(k)-busVoltageAngle_GIPFC(l)) - ...
                    gipfc_vse2*gipfc_bse2*sin(busVoltageAngle_GIPFC(k)-gipfc_thse2);
                J_gipfc_2(k,l) = busVoltage_GIPFC(k)*gipfc_bse2*sin(busVoltageAngle_GIPFC(k)-busVoltageAngle_GIPFC(l));
                J_gipfc_2(l,k) = -busVoltage_GIPFC(l)*gipfc_bse2*sin(busVoltageAngle_GIPFC(k)-busVoltageAngle_GIPFC(l));
                J_gipfc_2(l,l) = -busVoltage_GIPFC(k)*gipfc_bse2*sin(busVoltageAngle_GIPFC(k)-busVoltageAngle_GIPFC(l)) + ...
                    gipfc_vse2*gipfc_bse2*sin(busVoltageAngle_GIPFC(l)-gipfc_thse2);
            end
        end
 end


J_gipfc_3 = zeros(nbus);
    for i = 1:nbus
        for j = 1:nbus
            if ( i == gipfc_send ) && ( j == gipfc_rec1)
                J_gipfc_3(i,i) = busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse1 *...
                    sin(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j)) + busVoltage_GIPFC(i)*...
                    gipfc_vse1 * gipfc_bse1 * sin(busVoltageAngle_GIPFC(i) - gipfc_thse1);

                J_gipfc_3(i,j) = busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse1 *...
                    sin(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j));

                J_gipfc_3(j,i) = busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse1 *...
                    sin(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j));

                J_gipfc_3(j,j) = busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse1 *...
                    sin(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j)) - ...
                    busVoltage_GIPFC(j) * gipfc_vse1 * gipfc_bse1 * sin(busVoltageAngle_GIPFC(j) - gipfc_thse1);

            elseif ( j == gipfc_send ) && ( i == gipfc_rec1)
                J_gipfc_3(i,i) = busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse1 *...
                    sin(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j)) + busVoltage_GIPFC(i)*...
                    gipfc_vse1 * gipfc_bse1 * sin(busVoltageAngle_GIPFC(i) - gipfc_thse1);

                J_gipfc_3(i,j) = busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse1 *...
                    sin(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j));

                J_gipfc_3(j,i) = busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse1 *...
                    sin(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j));

                J_gipfc_3(j,j) = busVoltage_GIPFC(i) * busVoltage_GIPFC(j) * gipfc_bse1 *...
                    sin(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j)) - ...
                    busVoltage_GIPFC(j) * gipfc_vse1 * gipfc_bse1 * sin(busVoltageAngle_GIPFC(j) - gipfc_thse1);
            end
        end

        for k = 1 : nbus
            if i == gipfc_send && k == gipfc_rec2
                J_gipfc_3(i,k) = 0;

            elseif k == gipfc_send && i == gipfc_rec2
                J_gipfc_3(i,k) = 0; 
            end
        end

        for l = 1 : nbus
            if i == gipfc_send && l == gipfc_rec3
                J_gipfc_3(i,l) = 0;

            elseif l == gipfc_send && i == gipfc_rec3
                J_gipfc_3(i,l) = 0; 
            end
        end
    end

for k = 1:nbus
        for l = 1:nbus
            if (k == gipfc_rec2 && l == gipfc_rec3)
               J_gipfc_3(k,k) = -busVoltage_GIPFC(k) * busVoltage_GIPFC(l)*gipfc_bse2*sin(busVoltageAngle_GIPFC(k)-busVoltageAngle_GIPFC(l))...
                   + gipfc_bse2*busVoltage_GIPFC(k)*gipfc_vse2*sin(busVoltageAngle_GIPFC(k)-gipfc_thse2);

                J_gipfc_3(k,l) = busVoltage_GIPFC(k)*busVoltage_GIPFC(l)*gipfc_bse2*sin(busVoltageAngle_GIPFC(k) - busVoltageAngle_GIPFC(l));

                J_gipfc_3(l,k) = busVoltage_GIPFC(k)*busVoltage_GIPFC(l)*gipfc_bse2*sin(busVoltageAngle_GIPFC(k) - busVoltageAngle_GIPFC(l));

                J_gipfc_3(l,l) = busVoltage_GIPFC(k)*busVoltage_GIPFC(l)*gipfc_bse2*sin(busVoltageAngle_GIPFC(k) - busVoltageAngle_GIPFC(l))...
                    - gipfc_bse2*busVoltage_GIPFC(l)*gipfc_vse2*sin(busVoltageAngle_GIPFC(l) - gipfc_thse2);

            elseif (l == gipfc_rec2 && k == gipfc_rec3)
               J_gipfc_3(k,k) = -busVoltage_GIPFC(k)*busVoltage_GIPFC(l)*gipfc_bse2*sin(busVoltageAngle_GIPFC(k)-busVoltageAngle_GIPFC(l))...
                   + gipfc_bse2*busVoltage_GIPFC(k)*gipfc_vse2*sin(busVoltageAngle_GIPFC(k) - gipfc_thse2);

                J_gipfc_3(k,l) = busVoltage_GIPFC(k)*busVoltage_GIPFC(l)*gipfc_bse2*sin(busVoltageAngle_GIPFC(k) - busVoltageAngle_GIPFC(l));

                J_gipfc_3(l,k) = busVoltage_GIPFC(k)*busVoltage_GIPFC(l)*gipfc_bse2*sin(busVoltageAngle_GIPFC(k) - busVoltageAngle_GIPFC(l));

                J_gipfc_3(l,l) = busVoltage_GIPFC(k)*busVoltage_GIPFC(l)*gipfc_bse2*sin(busVoltageAngle_GIPFC(k) - busVoltageAngle_GIPFC(l))...
                    - gipfc_bse2*busVoltage_GIPFC(l)*gipfc_vse2*sin(busVoltageAngle_GIPFC(l) - gipfc_thse2);
            end
        end
    end

% JJ4 - Derivative of gipfc Reactive Power Injections with Voltages..
    J_gipfc_4 = zeros(nbus,nbus);
    for i = 1:nbus
        for j = 1:nbus
            if i==gipfc_send && j==gipfc_rec1
               J_gipfc_4(i,i) = busVoltage_GIPFC(j) * gipfc_bse1 * cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j))-...
                             gipfc_bse1 * gipfc_vse1 * cos(busVoltageAngle_GIPFC(i)-gipfc_thse1) - 2 * busVoltage_GIPFC(i) * gipfc_bse1;

               J_gipfc_4(i,j) = busVoltage_GIPFC(i) * gipfc_bse1 * cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j));

               J_gipfc_4(j,i) = busVoltage_GIPFC(j) * gipfc_bse1 * cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j));

               J_gipfc_4(j,j) = busVoltage_GIPFC(i) * gipfc_bse1 * cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j))+...
                             gipfc_bse1 * gipfc_vse1 * cos(busVoltageAngle_GIPFC(i) - gipfc_thse1) - 2 * busVoltage_GIPFC(j) * gipfc_bse1;

            elseif (j==gipfc_send && i==gipfc_rec1)
               J_gipfc_4(i,i) = busVoltage_GIPFC(j) * gipfc_bse1 * cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j))-...
                             gipfc_bse1 * gipfc_vse1 * cos(busVoltageAngle_GIPFC(i)-gipfc_thse1) - 2 * busVoltage_GIPFC(i) * gipfc_bse1;

               J_gipfc_4(i,j) = busVoltage_GIPFC(i) * gipfc_bse1 * cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j));

               J_gipfc_4(j,i) = busVoltage_GIPFC(j) * gipfc_bse1 * cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j));

               J_gipfc_4(j,j) = busVoltage_GIPFC(i) * gipfc_bse1 * cos(busVoltageAngle_GIPFC(i) - busVoltageAngle_GIPFC(j))+...
                             gipfc_bse1 * gipfc_vse1 * cos(busVoltageAngle_GIPFC(i) - gipfc_thse1) - 2 * busVoltage_GIPFC(j) * gipfc_bse1;
            end
        end

        for k = 1:nbus
            if (i==gipfc_send && k==gipfc_rec2)
               J_gipfc_4(i,k)=0;

            elseif (i==gipfc_rec2 && k==gipfc_send)
               J_gipfc_4(i,k)=0;
            end
        end

        for l = 1:nbus
            if (i==gipfc_send && l==gipfc_rec3)
               J_gipfc_4(i,l)=0;

            elseif (i==gipfc_rec3 && l==gipfc_send)
               J_gipfc_4(i,l)=0;
            end
        end        
    end

    for k = 1:nbus
        for l = 1:nbus
            if (k==gipfc_rec2 && l==gipfc_rec3)
               J_gipfc_4(k,k) = busVoltage_GIPFC(l)*gipfc_bse2*cos(busVoltageAngle_GIPFC(k) - busVoltageAngle_GIPFC(l))-...
                             gipfc_bse2*gipfc_vse2*cos(busVoltageAngle_GIPFC(k) - gipfc_thse2) - 2 * busVoltage_GIPFC(k) * gipfc_bse2;

               J_gipfc_4(k,l) = busVoltage_GIPFC(k)*gipfc_bse2*cos(busVoltageAngle_GIPFC(k) - busVoltageAngle_GIPFC(l));

               J_gipfc_4(l,k) = busVoltage_GIPFC(l)*gipfc_bse2*cos(busVoltageAngle_GIPFC(k) - busVoltageAngle_GIPFC(l));

               J_gipfc_4(l,l) = busVoltage_GIPFC(k)*gipfc_bse2*cos(busVoltageAngle_GIPFC(k) - busVoltageAngle_GIPFC(l))...
                   + gipfc_bse2*gipfc_vse2*cos(busVoltageAngle_GIPFC(l)-gipfc_thse2) - 2*busVoltage_GIPFC(l)*gipfc_bse2;

            elseif (l==gipfc_rec2 && k==gipfc_rec3)

               J_gipfc_4(k,k) = busVoltage_GIPFC(l)*gipfc_bse2*cos(busVoltageAngle_GIPFC(k) - busVoltageAngle_GIPFC(l))...
                   - gipfc_bse2*gipfc_vse2*cos(busVoltageAngle_GIPFC(k) - gipfc_thse2) - 2*busVoltage_GIPFC(k) * gipfc_bse2;

               J_gipfc_4(k,l) = busVoltage_GIPFC(k)*gipfc_bse2*cos(busVoltageAngle_GIPFC(k) - busVoltageAngle_GIPFC(l));

               J_gipfc_4(l,k) = busVoltage_GIPFC(l)*gipfc_bse2*cos(busVoltageAngle_GIPFC(k) - busVoltageAngle_GIPFC(l));

               J_gipfc_4(l,l) = busVoltage_GIPFC(k)*gipfc_bse2*cos(busVoltageAngle_GIPFC(k) - busVoltageAngle_GIPFC(l))...
                   + gipfc_bse2*gipfc_vse2*cos(busVoltageAngle_GIPFC(l)-gipfc_thse2) - 2*busVoltage_GIPFC(l)*gipfc_bse2;
            end
        end
    end


    Jacobian_gipfc = [J_gipfc_1 J_gipfc_2 ; J_gipfc_3 J_gipfc_4];

    %new jacobian after incorporating gipfc
    Jacobian_NR_gipfc = Jacobian_NR + Jacobian_gipfc;


    slack_bus = find(busType == 1);  %eliminating slack bus rows and cols
    Jacobian_NR_gipfc([slack_bus, slack_bus + nbus], :) = []; 
    Jacobian_NR_gipfc(:, [slack_bus, slack_bus + nbus]) = []; 
    Mismatch([slack_bus, slack_bus + nbus], :) = [] ;

    %eliminating PV bus
    PV_bus = find(busType == 2);
    Jacobian_NR_gipfc(PV_bus+nbus-2, :) = [];    %-2 because already 2 slack rows are eliminated
    Jacobian_NR_gipfc(:, PV_bus+nbus-2) = []; 
    Mismatch(PV_bus+nbus-2, :) = [] ;

    
    Corrections = Jacobian_NR_gipfc \ Mismatch ;

    delta_corrected = Corrections(1:nbus-1);
    v_corrected = Corrections(nbus:end);
    busVoltageAngle_GIPFC(2:nbus) = delta_corrected + busVoltageAngle_GIPFC(2:nbus);
    %busVoltage = busVoltage .* (1 + v_corrected);

    k = 1;
    for i = 2:nbus
        if busType(i) == 3
            busVoltage_GIPFC(i) = busVoltage_GIPFC(i) * ( 1 + v_corrected(k));
            k = k + 1;
        end
    end
    

    tolerance = max(abs(Mismatch)) ;       
    iteration = iteration+1
end

% plot(bus,busVoltage_GIPFC, 'linewidth', 2); xlabel("Bus Number");
% ylabel("Bus Voltage (pu)")
% hold on
% plot(bus, busVoltage, 'linewidth', 2);
% legend("After GIPFC","Before GIPFC")
% 
% figure;
% plot(bus,busVoltageAngle_GIPFC, 'linewidth', 2); xlabel("Bus Number");
% ylabel("Bus Voltage Angle (radian)")
% hold on
% plot(bus, busVoltageAngle, 'linewidth', 2);
% legend("After GIPFC","Before GIPFC")

% figure;
% plot(bus, P, 'linewidth', 2); xlabel("Bus Number");
% ylabel("Power Flow")
% hold on
% plot(bus, P_GIPFC, 'linewidth', 2);
% legend("Before GIPFC","After GIPFC") 

figure;
plot(bus, Q_GIPFC, 'linewidth', 2); xlabel("Bus Number");
ylabel("Power Flow")
hold on
plot(bus, Q, 'linewidth', 2);
legend("After GIPFC","Before GIPFC")
