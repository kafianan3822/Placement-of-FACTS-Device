clc; clear all; close all; 

busdata = xlsread("busdata.xlsx");

busdata = busdata(:, :);    %30 bus system 

Base_MVA = 100;
bus = busdata(:, 1);
nbus = length(busdata(:,1));
busType = busdata(:, 2);
busVoltage = busdata(:, 3);
busVoltageAngle = busdata(:, 4);
Pgen = busdata(:, 5) /Base_MVA ;
Qgen = busdata(:, 6) /Base_MVA ;
Pload = busdata(:, 7) /Base_MVA ;
Qload = busdata(:, 8) /Base_MVA ;
Qmin = busdata(:, 9) /Base_MVA ;
Qmax = busdata(:, 10) /Base_MVA ;
Qsh = busdata(:, 11) /Base_MVA ;

%%%line data
linedata = xlsread("linedata.xlsx");

linedata = linedata(1:41,:);

nline = length(linedata(:,1));
frombus = linedata(:, 2);
tobus = linedata(:, 3);
rline = linedata(:, 4);
xline = linedata(:, 5);
linecharging = linedata(:, 6);
linetap = linedata(:, 7);
lineMVAlimit = linedata(:, 8);

%%% ybus
zline = rline + 1i*xline;
yline = 1./zline;
blinecharge = 1i*linecharging;

Y_matrix = zeros(nbus,nbus);
for k = 1:nline
    Y_matrix(frombus(k) , tobus(k)) = Y_matrix(frombus(k), tobus(k)) - yline(k)/linetap(k);
    Y_matrix(tobus(k) , frombus(k)) = Y_matrix(frombus(k), tobus(k));
end

for i_bus = 1:nbus
    for i_line = 1:nline
        if frombus(i_line) == i_bus 
            Y_matrix(i_bus,i_bus) = Y_matrix(i_bus,i_bus) + yline(i_line)/(linetap(i_line)^2) + blinecharge(i_line);
        elseif tobus(i_line) == i_bus
            Y_matrix(i_bus,i_bus) = Y_matrix(i_bus,i_bus) + yline(i_line) + blinecharge(i_line);
        end
    end
end

G = real(Y_matrix);
B = imag(Y_matrix);

Ymag = abs(Y_matrix);
Yphase = angle(Y_matrix);


Pinj = Pgen - Pload;
Qinj = Qgen - Qload + Qsh ;

tolerance = 1;
iteration = 1;


while(tolerance > 0.0001 && iteration<=20)
    P = zeros(nbus,1);
    Q = zeros(nbus,1);

    for i= 1:nbus
        for k = 1:nbus
            P(i) = P(i) + busVoltage(i)*busVoltage(k)*Ymag(i,k) ...
                * cos(busVoltageAngle(k)-busVoltageAngle(i)+Yphase(i,k));
            Q(i) = Q(i) - busVoltage(i)*busVoltage(k)*Ymag(i,k) ...
                * sin(busVoltageAngle(k)-busVoltageAngle(i)+Yphase(i,k));
        end
    end

    for i = 1:nbus
        if(busType(i) == 2 && iteration>2)   
            if ( (Q(i) + Qload(i)) < Qmin(i) )
                Qinj(i) = Qmin(i) - Qload(i);
                busType(i) = 3;
            elseif ( (Q(i) + Qload(i)) > Qmax(i) )
                Qinj(i) = Qmax(i) - Qload(i);
                busType(i) = 3;
            end
        end
    end

    delP = Pinj - P;
    delQ = Qinj - Q;

    Mismatch = [delP; delQ];

    %%SubJacobians

    J1 = zeros(nbus, nbus);
    for i = 1:nbus
        for j = 1:nbus

             if (i == j)
                for k = 1:nbus
                    J1(i,j) = J1(i,j) - busVoltage(k)*busVoltage(i) *Ymag(i,k) ...
                        *sin(busVoltageAngle(k)-busVoltageAngle(i)+Yphase(i,k));
                end
                J1(i,j) = - busVoltage(i)^2 * B(i,j) - J1(i,j);
%                  J1(i,j) = - busVoltage(i)^2 * B(i,j) - Q(i);
             else
                 J1(i,j) = - Ymag(i,j)*busVoltage(i)*busVoltage(j)* ...
                     sin(busVoltageAngle(j)-busVoltageAngle(i)+Yphase(i,j));
             end
        end
    end



    J2 = zeros(nbus, nbus);
    for i = 1:nbus
        for j = 1:nbus
            
             if i == j 
                for k = 1:nbus
                    J2(i,j) = J2(i,j) + busVoltage(i)*busVoltage(k)*Ymag(i,k) ...
                        *cos(busVoltageAngle(k)-busVoltageAngle(i)+Yphase(i,k));
                end
                J2(i,j) = J2(i,j) + busVoltage(i)^2 * G(i,j);
%                  J2(i,j) = P(i) + busVoltage(i)^2 * G(i,j); 
             else
                 J2(i,j) = busVoltage(i)*busVoltage(j)*Ymag(i,j) ...
                         *cos(busVoltageAngle(j)-busVoltageAngle(i)+Yphase(i,j));
             end

        end 
    end



  J3 = zeros(nbus, nbus);
    for i = 1:nbus
        for j = 1:nbus
            
             if i == j 
                for k = 1:nbus
                    J3(i,j) = J3(i,j) + busVoltage(i)*busVoltage(k)*Ymag(i,k) ...
                        *cos(busVoltageAngle(k)-busVoltageAngle(i)+Yphase(i,k));
                end
                J3(i,j) = J3(i,j) - busVoltage(i)^2 * G(i,j);
%                  J3(i,j) = P(i) - busVoltage(i)^2 * G(i,j); 
             else
                 J3(i,j) = - busVoltage(i)*busVoltage(j)*Ymag(i,j) ...
                         *cos(busVoltageAngle(j)-busVoltageAngle(i)+Yphase(i,j));
             end

        end 
    end



    J4 = zeros(nbus, nbus);
    for i = 1:nbus
        for j = 1:nbus
            
             if i == j 
                for k = 1:nbus
                    J4(i,j) = J4(i,j) - busVoltage(i)*busVoltage(k)*Ymag(i,k) ...
                        *sin(busVoltageAngle(k)-busVoltageAngle(i)+Yphase(i,k));
                end
                J4(i,j) = J4(i,j) - busVoltage(i)^2 * B(i,j);
%                  J4(i,j) = Q(i) - busVoltage(i)^2 * B(i,j); 
             else
                 J4(i,j) = - busVoltage(i)*busVoltage(j)*Ymag(i,j) ...
                         *sin(busVoltageAngle(j)-busVoltageAngle(i)+Yphase(i,j));
             end

        end 
    end


    Jacobian_NR = [J1 J2; J3 J4];


    slack_bus = find(busType == 1);  %eliminating slack bus rows and cols
    Jacobian_NR([slack_bus, slack_bus + nbus], :) = []; 
    Jacobian_NR(:, [slack_bus, slack_bus + nbus]) = []; 
    Mismatch([slack_bus, slack_bus + nbus], :) = [] ;

    %eliminating PV bus
    PV_bus = find(busType == 2);
    Jacobian_NR(PV_bus+nbus-2, :) = [];    %-2 because already 2 slack rows are eliminated
    Jacobian_NR(:, PV_bus+nbus-2) = []; 
    Mismatch(PV_bus+nbus-2, :) = [] ;

    
    Corrections = Jacobian_NR \ Mismatch ;

    delta_corrected = Corrections(1:nbus-1);
    v_corrected = Corrections(nbus:end);
    busVoltageAngle(2:nbus) = delta_corrected + busVoltageAngle(2:nbus);
    %busVoltage = busVoltage .* (1 + v_corrected);

    k = 1;
    for i = 2:nbus
        if busType(i) == 3
            busVoltage(i) = busVoltage(i) * ( 1 + v_corrected(k));
            k = k + 1;
        end
    end
    

    tolerance = max(abs(Mismatch)) ;       
    iteration = iteration+1
end
