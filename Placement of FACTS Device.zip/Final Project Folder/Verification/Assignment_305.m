clc; clear all; close all; 

%%%Bus Data
BusData = xlsread("Bus Data.xlsx");

Base_MVA = 100;

Bus_no = BusData(:,1);
n = length(Bus_no);
Pgen = BusData(:, 2) /Base_MVA ;
Qgen = BusData(:, 3) /Base_MVA ;
Pload = BusData(:, 4) /Base_MVA ;
Qload = BusData(:, 5) /Base_MVA ;
Voltage = BusData(:, 6);
VoltageAngle = BusData(:, 7);
Bus_Type = BusData(:, 8);  % 1-Slack, 2-Load(PQ), 3-PV

%%%Load Data
LineData = xlsread("Line Data.xlsx");

nline = length(LineData(:,1));
FromBus = LineData(:, 2);
ToBus = LineData(:, 3);
Rline = LineData(:, 4);
Xline = LineData(:, 5);
GLine = LineData(:, 6);
BLine = LineData(:, 7);
Linecharging = LineData(:, 9);


%%% ybus
Z_line = Rline + 1i*Xline;
Y_line = 1./Z_line;
B_Linecharge = 1i*Linecharging;

Ymat = zeros(n,n);
for k = 1:nline
    Ymat(FromBus(k) , ToBus(k)) = Ymat(FromBus(k), ToBus(k)) - Y_line(k);
    Ymat(ToBus(k) , FromBus(k)) = Ymat(FromBus(k), ToBus(k));
end

for i_bus = 1:n
    for i_line = 1:nline
        if FromBus(i_line) == i_bus 
            Ymat(i_bus,i_bus) = Ymat(i_bus,i_bus) + Y_line(i_line) + B_Linecharge(i_line);
        elseif ToBus(i_line) == i_bus
            Ymat(i_bus,i_bus) = Ymat(i_bus,i_bus) + Y_line(i_line) + B_Linecharge(i_line);
        end
    end
end

G = real(Ymat);
B = imag(Ymat);

Ymag = abs(Ymat);
Yangle = angle(Ymat);


Psch = Pgen - Pload;
Qsch = Qgen - Qload ;

tol = 1;
iter = 1;



while(tol > 0.0001 && iter<=1)
    P = zeros(n,1);
    Q = zeros(n,1);
    
    for i= 1:n
        for k = 1:n
            P(i) = P(i) + Voltage(i)*Voltage(k)*Ymag(i,k) ...
                * cos(VoltageAngle(k)-VoltageAngle(i)+Yangle(i,k));

            Q(i) = Q(i) - Voltage(i)*Voltage(k)*Ymag(i,k) ...
                * sin(VoltageAngle(k)-VoltageAngle(i)+Yangle(i,k));
        end
    end

    delP = Psch - P;
    delQ = Qsch - Q;

    Mismatch = [delP; delQ];

    %%SubJacobians

    J1 = zeros(n, n);
    for i = 1:n
        for j = 1:n

             if (i == j)
                for k = 1:n
                    J1(i,j) = J1(i,j) - Voltage(k)*Voltage(i) *Ymag(i,k) ...
                        *sin(VoltageAngle(k)-VoltageAngle(i)+Yangle(i,k));
                end
                J1(i,j) = - Voltage(i)^2 * B(i,j) - J1(i,j);
%                  J1(i,j) = - Bus_Voltage(i)^2 * B(i,j) - Q(i);
             else
                 J1(i,j) = - Ymag(i,j)*Voltage(i)*Voltage(j)* ...
                     sin(VoltageAngle(j)-VoltageAngle(i)+Yangle(i,j));
             end
        end
    end

    J2 = zeros(n, n);
    for i = 1:n
        for j = 1:n
             if i == j 
                for k = 1:n
                    J2(i,j) = J2(i,j) + Voltage(i)*Voltage(k)*Ymag(i,k) ...
                        *cos(VoltageAngle(k)-VoltageAngle(i)+Yangle(i,k));
                end
                J2(i,j) = J2(i,j) + Voltage(i)^2 * G(i,j);
%                  J2(i,j) = P(i) + Bus_Voltage(i)^2 * G(i,j); 
             else
                 J2(i,j) = Voltage(i)*Voltage(j)*Ymag(i,j) ...
                         *cos(VoltageAngle(j)-VoltageAngle(i)+Yangle(i,j));
             end

        end 
    end

  J3 = zeros(n, n);
    for i = 1:n
        for j = 1:n
            
             if i == j 
                for k = 1:n
                    J3(i,j) = J3(i,j) + Voltage(i)*Voltage(k)*Ymag(i,k) ...
                        *cos(VoltageAngle(k)-VoltageAngle(i)+Yangle(i,k));
                end
                J3(i,j) = J3(i,j) - Voltage(i)^2 * G(i,j);
%                  J3(i,j) = P(i) - Bus_Voltage(i)^2 * G(i,j); 
             else
                 J3(i,j) = - Voltage(i)*Voltage(j)*Ymag(i,j) ...
                         *cos(VoltageAngle(j)-VoltageAngle(i)+Yangle(i,j));
             end

        end 
    end

    J4 = zeros(n, n);
    for i = 1:n
        for j = 1:n
            
             if i == j 
                for k = 1:n
                    J4(i,j) = J4(i,j) - Voltage(i)*Voltage(k)*Ymag(i,k) ...
                        *sin(VoltageAngle(k)-VoltageAngle(i)+Yangle(i,k));
                end
                J4(i,j) = J4(i,j) - Voltage(i)^2 * B(i,j);
%                  J4(i,j) = Q(i) - Bus_Voltage(i)^2 * B(i,j); 
             else
                 J4(i,j) = - Voltage(i)*Voltage(j)*Ymag(i,j) ...
                         *sin(VoltageAngle(j)-VoltageAngle(i)+Yangle(i,j));
             end

        end 
    end


    Jacobian_NR = [J1 J2; J3 J4];


    slack_bus = find(Bus_Type == 1);  %eliminating slack bus rows and cols
    Jacobian_NR([slack_bus, slack_bus + n], :) = []; 
    Jacobian_NR(:, [slack_bus, slack_bus + n]) = []; 
    Mismatch([slack_bus, slack_bus + n], :) = [] ;

    %eliminating PV bus
    PV_bus = find(Bus_Type == 3);
    Jacobian_NR(PV_bus+n-2, :) = [];    %-2 because already 2 slack rows are eliminated
    Jacobian_NR(:, PV_bus+n-2) = []; 
    Mismatch(PV_bus+n-2, :) = [] ;

    %Corrections------
    Corrections = Jacobian_NR \ Mismatch ;

    delta_corrected = Corrections(1:n-1);
    v_corrected = Corrections(n:end);
    VoltageAngle(2:n) = delta_corrected + VoltageAngle(2:n);
    %busVoltage = busVoltage .* (1 + v_corrected);

    k = 1;
    for i = 2:n
        if Bus_Type(i) == 2
            Voltage(i) = Voltage(i) * ( 1 + v_corrected(k))
            iter
            k = k + 1;
        end
    end
    
    tol = max(abs(Mismatch)) ;       
    iter = iter+1;
end


