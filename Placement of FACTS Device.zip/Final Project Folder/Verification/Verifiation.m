%%%% Example 9.5
clc; clear all; close all; 

%%%Bus Data
Bus_Data = xlsread("Bus Data.xlsx");

Base_MVA = 100;

Bus_no = Bus_Data(:,1);
n_bus = length(Bus_no);
P_gen = Bus_Data(:, 2) /Base_MVA ;
Q_gen = Bus_Data(:, 3) /Base_MVA ;
P_load = Bus_Data(:, 4) /Base_MVA ;
Q_load = Bus_Data(:, 5) /Base_MVA ;
Bus_Voltage = Bus_Data(:, 6);
Bus_VoltageAngle = Bus_Data(:, 7);
%Bus_Remarks = Bus_Data(:, 7);
Bus_Type = Bus_Data(:, 8);  % 1-Slack, 2-Load(PQ), 3-PV

%Qsh = Bus_Data(:, 11) /Base_MVA ;

%%%Load Data
Line_Data = xlsread("Line Data.xlsx");

line_no = Line_Data(:,1);
n_line = length(line_no);
From_Bus = Line_Data(:, 2);
To_Bus = Line_Data(:, 3);
R_line = Line_Data(:, 4);
X_line = Line_Data(:, 5);
G_Line = Line_Data(:, 6);
B_Line = Line_Data(:, 7);
Linecharging = Line_Data(:, 9);


%%% ybus
Z_line = R_line + 1i*X_line;
Y_line = 1./Z_line;
B_Linecharge = 1i*Linecharging;

Y_matrix = zeros(n_bus,n_bus);
for k = 1:n_line
    Y_matrix(From_Bus(k) , To_Bus(k)) = Y_matrix(From_Bus(k), To_Bus(k)) - Y_line(k);
    Y_matrix(To_Bus(k) , From_Bus(k)) = Y_matrix(From_Bus(k), To_Bus(k));
end

for i_bus = 1:n_bus
    for i_line = 1:n_line
        if From_Bus(i_line) == i_bus 
            Y_matrix(i_bus,i_bus) = Y_matrix(i_bus,i_bus) + Y_line(i_line) + B_Linecharge(i_line);
        elseif To_Bus(i_line) == i_bus
            Y_matrix(i_bus,i_bus) = Y_matrix(i_bus,i_bus) + Y_line(i_line) + B_Linecharge(i_line);
        end
    end
end

G = real(Y_matrix);
B = imag(Y_matrix);

Ymag = abs(Y_matrix);
Yphase = angle(Y_matrix);


Pinj = P_gen - P_load;
Qinj = Q_gen - Q_load ;

tolerance = 1;
iteration = 1;

P = zeros(n_bus,1);
Q = zeros(n_bus,1);

while(tolerance > 0.0001 && iteration<=1)
    for i= 1:n_bus
        for k = 1:n_bus
            P(i) = P(i) + Bus_Voltage(i)*Bus_Voltage(k)*Ymag(i,k) ...
                * cos(Bus_VoltageAngle(k)-Bus_VoltageAngle(i)+Yphase(i,k));

            Q(i) = Q(i) - Bus_Voltage(i)*Bus_Voltage(k)*Ymag(i,k) ...
                * sin(Bus_VoltageAngle(k)-Bus_VoltageAngle(i)+Yphase(i,k));
        end
    end

%     for i = 1:n_bus
%         if(Bus_Type(i) == 2 && iteration>2)   %why >2?
%             if ( (Q(i) + Q_load(i)) < Qmin(i) )
%                 Qinj(i) = Qmin(i) - Q_load(i);
%                 Bus_Type(i) = 3;
%             elseif ( (Q(i) + Q_load(i)) > Qmax(i) )
%                 Qinj(i) = Qmax(i) - Q_load(i);
%                 Bus_Type(i) = 3;
%             end
%         end
%     end

    delP = Pinj - P;
    delQ = Qinj - Q;

    Mismatch = [delP; delQ];

    %%SubJacobians

    J1 = zeros(n_bus, n_bus);
    for i = 1:n_bus
        for j = 1:n_bus

             if (i == j)
                for k = 1:n_bus
                    J1(i,j) = J1(i,j) - Bus_Voltage(k)*Bus_Voltage(i) *Ymag(i,k) ...
                        *sin(Bus_VoltageAngle(k)-Bus_VoltageAngle(i)+Yphase(i,k));
                end
                J1(i,j) = - Bus_Voltage(i)^2 * B(i,j) - J1(i,j);
%                  J1(i,j) = - Bus_Voltage(i)^2 * B(i,j) - Q(i);
             else
                 J1(i,j) = - Ymag(i,j)*Bus_Voltage(i)*Bus_Voltage(j)* ...
                     sin(Bus_VoltageAngle(j)-Bus_VoltageAngle(i)+Yphase(i,j));
             end
        end
    end



    J2 = zeros(n_bus, n_bus);
    for i = 1:n_bus
        for j = 1:n_bus
            
             if i == j 
                for k = 1:n_bus
                    J2(i,j) = J2(i,j) + Bus_Voltage(i)*Bus_Voltage(k)*Ymag(i,k) ...
                        *cos(Bus_VoltageAngle(k)-Bus_VoltageAngle(i)+Yphase(i,k));
                end
                J2(i,j) = J2(i,j) + Bus_Voltage(i)^2 * G(i,j);
%                  J2(i,j) = P(i) + Bus_Voltage(i)^2 * G(i,j); 
             else
                 J2(i,j) = Bus_Voltage(i)*Bus_Voltage(j)*Ymag(i,j) ...
                         *cos(Bus_VoltageAngle(j)-Bus_VoltageAngle(i)+Yphase(i,j));
             end

        end 
    end



  J3 = zeros(n_bus, n_bus);
    for i = 1:n_bus
        for j = 1:n_bus
            
             if i == j 
                for k = 1:n_bus
                    J3(i,j) = J3(i,j) + Bus_Voltage(i)*Bus_Voltage(k)*Ymag(i,k) ...
                        *cos(Bus_VoltageAngle(k)-Bus_VoltageAngle(i)+Yphase(i,k));
                end
                J3(i,j) = J3(i,j) - Bus_Voltage(i)^2 * G(i,j);
%                  J3(i,j) = P(i) - Bus_Voltage(i)^2 * G(i,j); 
             else
                 J3(i,j) = - Bus_Voltage(i)*Bus_Voltage(j)*Ymag(i,j) ...
                         *cos(Bus_VoltageAngle(j)-Bus_VoltageAngle(i)+Yphase(i,j));
             end

        end 
    end



    J4 = zeros(n_bus, n_bus);
    for i = 1:n_bus
        for j = 1:n_bus
            
             if i == j 
                for k = 1:n_bus
                    J4(i,j) = J4(i,j) - Bus_Voltage(i)*Bus_Voltage(k)*Ymag(i,k) ...
                        *sin(Bus_VoltageAngle(k)-Bus_VoltageAngle(i)+Yphase(i,k));
                end
                J4(i,j) = J4(i,j) - Bus_Voltage(i)^2 * B(i,j);
%                  J4(i,j) = Q(i) - Bus_Voltage(i)^2 * B(i,j); 
             else
                 J4(i,j) = - Bus_Voltage(i)*Bus_Voltage(j)*Ymag(i,j) ...
                         *sin(Bus_VoltageAngle(j)-Bus_VoltageAngle(i)+Yphase(i,j));
             end

        end 
    end


    Jacobian_NR = [J1 J2; J3 J4];




    slack_bus = find(Bus_Type == 1);  %eliminating slack bus rows and cols
    Jacobian_NR([slack_bus, slack_bus + n_bus], :) = []; 
    Jacobian_NR(:, [slack_bus, slack_bus + n_bus]) = []; 
    Mismatch([slack_bus, slack_bus + n_bus], :) = [] ;

    %eliminating PV bus
    PV_bus = find(Bus_Type == 3);
    Jacobian_NR(PV_bus+n_bus-2, :) = [];    %-2 because already 2 slack rows are eliminated
    Jacobian_NR(:, PV_bus+n_bus-2) = []; 
    Mismatch(PV_bus+n_bus-2, :) = [] ;

    %Corrections------
    Corrections = Jacobian_NR \ Mismatch ;

    delta_corrected = Corrections(1:n_bus-1);
    v_corrected = Corrections(n_bus:end);
    Bus_VoltageAngle(2:n_bus) = delta_corrected + Bus_VoltageAngle(2:n_bus);
    %busVoltage = busVoltage .* (1 + v_corrected);

    k = 1;
    for i = 2:n_bus
        if Bus_Type(i) == 2
            Bus_Voltage(i) = Bus_Voltage(i) * ( 1 + v_corrected(k))
            iteration
            k = k + 1;
        end
    end
    

    tolerance = max(abs(Mismatch)) ;       
    iteration = iteration+1;
end


