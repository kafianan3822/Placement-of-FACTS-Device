%%%% Assignment Example 9.5
clc; clear all; close all; 
ID = 060;  %2006043

%%%Bus Data
Bus_Data = xlsread("Bus Data.xlsx");

Base_MVA = 100;

Bus_No = Bus_Data(:,1);
n_Bus = length(Bus_No);
P_Gen = Bus_Data(:, 2) /Base_MVA ;
Q_Gen = Bus_Data(:, 3) /Base_MVA ;
P_Load = Bus_Data(:, 4) /Base_MVA ;
Q_Load = Bus_Data(:, 5) /Base_MVA ;
Bus_Voltage = Bus_Data(:, 6);
Bus_Voltage_Angle = Bus_Data(:, 7);
%Bus_Remarks = Bus_Data(:, 7);
Bus_Type = Bus_Data(:, 8); %From Remarks, We defined 1-Slack, 2-PQ, 3-PV

%%%Load Data
Line_Data = xlsread("Line Data.xlsx");

Line_No = Line_Data(:,1);
n_Line = length(Line_No);
From_Bus = Line_Data(:, 2);
To_Bus = Line_Data(:, 3);
R_line = Line_Data(:, 4);
X_line = Line_Data(:, 5);
G_Line = Line_Data(:, 6);
B_Line = Line_Data(:, 7);
Line_Charging = Line_Data(:, 9);

%for Y_bus
Z_line = R_line + 1i*X_line;
Y_line = 1./Z_line;
B_Linecharge = 1i*Line_Charging;

%Formation of Y Matrix from the bus and line data
Y_matrix = zeros(n_Bus,n_Bus);
for k = 1:n_Line   %Off Diagonal Elements
    Y_matrix(From_Bus(k) , To_Bus(k)) = Y_matrix(From_Bus(k), To_Bus(k)) - Y_line(k);
    Y_matrix(To_Bus(k) , From_Bus(k)) = Y_matrix(From_Bus(k), To_Bus(k)); %symmetric
end

for i_bus = 1:n_Bus   %Diagonal Elements
    for i_line = 1:n_Line
        if From_Bus(i_line) == i_bus 
            Y_matrix(i_bus,i_bus) = Y_matrix(i_bus,i_bus) + Y_line(i_line) + B_Linecharge(i_line);
        elseif To_Bus(i_line) == i_bus
            Y_matrix(i_bus,i_bus) = Y_matrix(i_bus,i_bus) + Y_line(i_line) + B_Linecharge(i_line);
        end
    end
end

%extra capacitor susceptance with (15 + ID/100) MVAR between Bus 3 and reference
%only effect only in Y(3,3), B=Q/V^2 /Base_MVA 
Y_capacitor = 1i* (15 + (ID/1000) ) /Base_MVA;
Y_matrix(3,3) = Y_matrix(3,3) +  Y_capacitor;

G = real(Y_matrix);
B = imag(Y_matrix);

Y_Mag = abs(Y_matrix);
Y_Phase = angle(Y_matrix);

P_scheduled = P_Gen - P_Load;
Q_scheduled = Q_Gen - Q_Load ;

Tolerance = 1;
iteration_No = 1;


while(Tolerance > 0.0001 && iteration_No<=1) %for the first iteration

P_calc = zeros(n_Bus,1);
Q_calc = zeros(n_Bus,1);

    for i= 1:n_Bus
        for k = 1:n_Bus
            P_calc(i) = P_calc(i) + Bus_Voltage(i)*Bus_Voltage(k)*Y_Mag(i,k) ...
                * cos(Bus_Voltage_Angle(k)-Bus_Voltage_Angle(i)+Y_Phase(i,k));

            Q_calc(i) = Q_calc(i) - Bus_Voltage(i)*Bus_Voltage(k)*Y_Mag(i,k) ...
                * sin(Bus_Voltage_Angle(k)-Bus_Voltage_Angle(i)+Y_Phase(i,k));
        end
    end

    del_P = P_scheduled - P_calc;
    del_Q = Q_scheduled - Q_calc;

    Mismatch = [del_P; del_Q];

    %SubJacobians---------------

    J11 = zeros(n_Bus, n_Bus);
    for i = 1:n_Bus
        for j = 1:n_Bus

             if (i == j)       %diagonal elements
                for k = 1:n_Bus
                    J11(i,j) = J11(i,j) - Bus_Voltage(k)*Bus_Voltage(i) *Y_Mag(i,k) ...
                        *sin(Bus_Voltage_Angle(k)-Bus_Voltage_Angle(i)+Y_Phase(i,k));
                end
                J11(i,j) = - Bus_Voltage(i)^2 * B(i,j) - J11(i,j); %-V^2*B-Q
             else
                 J11(i,j) = - Y_Mag(i,j)*Bus_Voltage(i)*Bus_Voltage(j)* ...
                     sin(Bus_Voltage_Angle(j)-Bus_Voltage_Angle(i)+Y_Phase(i,j));
             end
        end
    end


    J12 = zeros(n_Bus, n_Bus);
    for i = 1:n_Bus
        for j = 1:n_Bus
             if (i == j)      %diagonal elements
                for k = 1:n_Bus
                    J12(i,j) = J12(i,j) + Bus_Voltage(i)*Bus_Voltage(k)*Y_Mag(i,k) ...
                        *cos(Bus_Voltage_Angle(k)-Bus_Voltage_Angle(i)+Y_Phase(i,k));
                end
                J12(i,j) = J12(i,j) + Bus_Voltage(i)^2 * G(i,j); %P+V^2*G
             else
                 J12(i,j) = Bus_Voltage(i)*Bus_Voltage(j)*Y_Mag(i,j) ...
                         *cos(Bus_Voltage_Angle(j)-Bus_Voltage_Angle(i)+Y_Phase(i,j));
             end

        end 
    end


  J21 = zeros(n_Bus, n_Bus);
    for i = 1:n_Bus
        for j = 1:n_Bus
            if i == j   %diagonal elements
                for k = 1:n_Bus
                    J21(i,j) = J21(i,j) + Bus_Voltage(i)*Bus_Voltage(k)*Y_Mag(i,k) ...
                        *cos(Bus_Voltage_Angle(k)-Bus_Voltage_Angle(i)+Y_Phase(i,k));
                end
                J21(i,j) = J21(i,j) - Bus_Voltage(i)^2 * G(i,j); %P-V^2*G
             else
                 J21(i,j) = - Bus_Voltage(i)*Bus_Voltage(j)*Y_Mag(i,j) ...
                         *cos(Bus_Voltage_Angle(j)-Bus_Voltage_Angle(i)+Y_Phase(i,j));
             end

        end 
    end

    J22 = zeros(n_Bus, n_Bus);
    for i = 1:n_Bus
        for j = 1:n_Bus
            
             if i == j  %diagonal elements
                for k = 1:n_Bus
                    J22(i,j) = J22(i,j) - Bus_Voltage(i)*Bus_Voltage(k)*Y_Mag(i,k) ...
                        *sin(Bus_Voltage_Angle(k)-Bus_Voltage_Angle(i)+Y_Phase(i,k));
                end
                J22(i,j) = J22(i,j) - Bus_Voltage(i)^2 * B(i,j); %Q-V^2*B
             else
                 J22(i,j) = - Bus_Voltage(i)*Bus_Voltage(j)*Y_Mag(i,j) ...
                         *sin(Bus_Voltage_Angle(j)-Bus_Voltage_Angle(i)+Y_Phase(i,j));
             end

        end 
    end

    Jacobian_Matrix = [J11 J12; J21 J22];

    %eliminating slack bus rows and columns
    slack_bus_index = find(Bus_Type == 1);  
    Jacobian_Matrix([slack_bus_index, slack_bus_index + n_Bus], :) = []; 
    Jacobian_Matrix(:, [slack_bus_index, slack_bus_index + n_Bus]) = []; 
    Mismatch([slack_bus_index, slack_bus_index + n_Bus], :) = [] ;

    %eliminating PV bus
    PV_bus = find(Bus_Type == 3);
    Jacobian_Matrix(PV_bus+n_Bus-2, :) = [];   %-2 because already 2 slack rows are eliminated
    Jacobian_Matrix(:, PV_bus+n_Bus-2) = []; 
    Mismatch(PV_bus+n_Bus-2, :) = [] ;

    %Corrections-----------
    Corrections = Jacobian_Matrix \ Mismatch ;

    delta_Corrected = Corrections(1:n_Bus-1);
    Voltage_Corrected = Corrections(n_Bus:end);

    %Update
    Bus_Voltage_Angle(2:n_Bus) = delta_Corrected + Bus_Voltage_Angle(2:n_Bus);
    
    %Bus_Voltage = Bus_Voltage .* (1 + Voltage_Corrected);
    k = 1;
    for i = 2:n_Bus
        if Bus_Type(i) == 2     %only Load Bus Voltages are changed
            Bus_Voltage(i) = Bus_Voltage(i) * ( 1 + Voltage_Corrected(k));
            k = k + 1;
        end
    end
    Bus_Voltage_Angle_Degree = Bus_Voltage_Angle * 180/pi;
    
    Tolerance = max(abs(Mismatch)) ;       
    iteration_No = iteration_No + 1;
end


